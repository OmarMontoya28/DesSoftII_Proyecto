import static constantes.PrecioProductos.*;

public class Factura {
    //Atributos
    private int[] cantidadProductoFactura;
	private boolean jubilado;
	private double subtotalFactura;
	private double descuentoFactura;
	private double totalFactura;

    //Método Constructor
    public Factura(int[] cantidadProductoFactura, boolean jubilado) {
        this.cantidadProductoFactura = new int[19]; //Se inicializa el arreglo
		this.jubilado = jubilado; //Se asigna el valor del parámetro al atributo jubilado

        for (int i=0; i<19; i++) { //Se recorre el arreglo parámetro para asignarle sus valores al atributo cantidadProductoFactura
            this.cantidadProductoFactura[i] = cantidadProductoFactura[i];
        }

		this.setSubtotalFactura(); //Calcular el Subtotal de la factura
		this.setDescuentoFactura(); //Calcular el Descuento de Jubilado
		this.setTotalFactura(); //Calcular el Total Final de la factura
    }

    //Método Getter atributo cantidadProductoFactura
    public int getCantidadProductoFactura(int i) {
        return this.cantidadProductoFactura[i];
    }

	//Método Getter atributo jubilado
	public boolean isJubilado() {
		return jubilado;
	}

	//Método Getter atributo subtotalFactura
	public double getSubtotalFactura() {
		return subtotalFactura;
	}

	//Método Getter atributo descuentoFactura
	public double getDescuentoFactura() {
		return descuentoFactura;
	}

	//Método Getter atributo totalFactura
	public double getTotalFactura() {
		return totalFactura;
	}

	//Método para calcular el Subtotal de la factura procesada
	public void setSubtotalFactura() {
		for (int i=0;i<19;i++) {
			if(cantidadProductoFactura[i] > 0) {
				this.subtotalFactura += getPrecioProducto(i)*this.cantidadProductoFactura[i];
			}
		}
	}

	//Método para calcular el Descuento de la factura procesada
	public void setDescuentoFactura() {
		if (this.jubilado) {
			this.descuentoFactura = this.subtotalFactura * 0.20;
		} else {
			this.descuentoFactura = 0;
		}
	}

	//Método para calcular el Total Final de la factura procesada
	public void setTotalFactura(){
		this.totalFactura = this.subtotalFactura - this.descuentoFactura;
	}
}