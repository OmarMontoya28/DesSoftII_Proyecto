import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MenuProductos {
    //Instancia BufferedReader
    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(isr);

    //Consulta que muestra los productos disponibles y precios en el Menu Universitario
    public void mostrarMenuProductos() {
        boolean salirMenuProductos;
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃             CAFE DE CINE UNIVERSITARIO             ┃");
        System.out.println("\t┃           MENU DE PRODUCTOS DISPONIBLES            ┃");
        System.out.println("\t┠────────────────────────────────────────────────────┨");
        System.out.println("\t┠─────────────────────────────┬────────┬─────────────┨");
        System.out.println("\t┃           Producto          │ Precio │ Acaramelado ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Popcorn Chico               │ $1.25  │ $0.50       ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Popcorn Mediano             │ $2.00  │ $0.50       ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Popcorn Grande              │ $3.00  │ $0.50       ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Hot Dog                     │ $2.50  │             ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Refresco Pequeño            │ $1.30  │             ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Refresco Mediano            │ $2.00  │             ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Refresco Grande             │ $2.75  │             ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Agua                        │ $1.50  │             ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Chocolate                   │ $1.75  │             ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Combo1:                     │        │             ┃");
        System.out.println("\t┃    (x1) Popcorn Mediano     │ $4.50  │ $0.50       ┃");
        System.out.println("\t┃    (x1) Refresco Grande     │        │             ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Combo2:                     │        │             ┃");
        System.out.println("\t┃    (x1) Hot Dog             │ $5.00  │ $0.50       ┃");
        System.out.println("\t┃    (x1) Refresco Grande     │        │             ┃");
        System.out.println("\t┠─────────────────────────────┼────────┼─────────────┨");
        System.out.println("\t┃ Combo3:                     │        │             ┃");
        System.out.println("\t┃    (x1) Popcorn Grande      │ $6.80  │ $0.50       ┃");
        System.out.println("\t┃    (x2) Refrescos Medianos  │        │             ┃");
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┷━━━━━━━━┷━━━━━━━━━━━━━┛");
        do {
            System.out.print("\tIngrese (0) para regresar al menu principal: ");
            try {
                int respuestaSalirMenuProductos = Integer.parseInt(br.readLine());
                if (respuestaSalirMenuProductos == 0) {
                    salirMenuProductos = true;
                } else {
                    System.out.println("\tHa ingresado un valor incorrecto");
                    System.out.println("\tInténtelo nuevamente");
                    salirMenuProductos = false;
                }
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente");
                salirMenuProductos = false;
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");
                System.out.println("\tInténtelo nuevamente");
                salirMenuProductos = false;
            }
        } while(!salirMenuProductos);
    }
}
