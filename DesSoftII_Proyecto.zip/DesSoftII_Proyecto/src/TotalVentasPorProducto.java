import static constantes.NombreProductos.*;

public class TotalVentasPorProducto {
    //Atributos
    private int[] totalCantidadProducto;
    private int[] totalCantidadTipoProducto; //Guarda las cantidades totales vendidas por tipo de producto
    private double[] totalVentaTipoProducto; //Guarda el monto total vendido por tipo de producto
    private double totalSubtotalCafeteria; //Guarda el Subtotal recaudado por la cafeteria
    private double totalDescuentoCafeteria; //Guarda el Total de descuentos aplicados a todas las facturas
    private double granTotalCafeteria; //Guarda el Total final recaudado por la cafeteria

    //Método Constructor Total de Ventas Por Producto
    public TotalVentasPorProducto(int[] totalCantidadProducto){
        this.totalCantidadProducto = totalCantidadProducto;
    }

    //Método Constructor Total Recaudado
    public TotalVentasPorProducto(double totalSubtotalFactura, double totalDescuentoFactura, double granTotalFactura){
        this.totalSubtotalCafeteria = totalSubtotalFactura;
        this.totalDescuentoCafeteria = totalDescuentoFactura;
        this.granTotalCafeteria = granTotalFactura;
    }

    //Método Constructor Aporte de Cada Producto
    public TotalVentasPorProducto(int[] totalCantidadProducto, double totalSubtotalFactura){
        this.totalCantidadProducto = totalCantidadProducto;
        this.totalSubtotalCafeteria = totalSubtotalFactura;
    }

    //Método Getter atributo totalCantidadTipoProducto (dato individual)
    public int getTotalCantidadTipoProducto(int i) {
        return this.totalCantidadTipoProducto[i];
    }

    //Método Getter atributo totalVentaTipoProducto (dato individual)
    public double getTotalVentaTipoProducto(int i) {
        return this.totalVentaTipoProducto[i];
    }

    //Método para calcular la cantidad total vendida por tipo de producto
    public void calcularTotalCantidadPorTipoProducto() {
        this.totalCantidadTipoProducto = new int[17]; //Inicialización del arreglo
        for (int i=0; i<19; i++) {
            if (totalCantidadProducto[i] > 0) {
                switch (getNombreProducto(i)) {
                    case "Popcorn Chico":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[1] += this.totalCantidadProducto[i]; //"Popcorn Chico++"
                        this.totalCantidadTipoProducto[2] += this.totalCantidadProducto[i]; //"Popcorn Chico Regular++"
                        break;
                    case "Popcorn Chico Acaramelado":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[1] += this.totalCantidadProducto[i]; //"Popcorn Chico++"
                        this.totalCantidadTipoProducto[3] += this.totalCantidadProducto[i]; //"Popcorn Chico Acaramelado++"
                        break;
                    case "Popcorn Mediano":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[4] += this.totalCantidadProducto[i]; //"Popcorn Mediano++"
                        this.totalCantidadTipoProducto[5] += this.totalCantidadProducto[i]; //"Popcorn Mediano Regular++"
                        break;
                    case "Popcorn Mediano Acaramelado":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[4] += this.totalCantidadProducto[i]; //"Popcorn Mediano++"
                        this.totalCantidadTipoProducto[6] += this.totalCantidadProducto[i]; //"Popcorn Mediano Acaramelado++"
                        break;
                    case "Popcorn Grande":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[7] += this.totalCantidadProducto[i]; //"Popcorn Grande+"
                        this.totalCantidadTipoProducto[8] += this.totalCantidadProducto[i]; //"Popcorn Grande Regular++"
                        break;
                    case "Popcorn Grande Acaramelado":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[7] += this.totalCantidadProducto[i]; //"Popcorn Grande+"
                        this.totalCantidadTipoProducto[9] += this.totalCantidadProducto[i]; //"Popcorn Grande Acaramelado++"
                        break;
                    case "Hot Dog":
                        this.totalCantidadTipoProducto[10] += this.totalCantidadProducto[i]; //"Hot Dog++"
                        break;
                    case "Refresco Pequeño":
                        this.totalCantidadTipoProducto[11] += this.totalCantidadProducto[i]; //"Refresco++"
                        this.totalCantidadTipoProducto[12] += this.totalCantidadProducto[i]; //"Refresco Pequeño++"
                        break;
                    case "Refresco Mediano":
                        this.totalCantidadTipoProducto[11] += this.totalCantidadProducto[i]; //"Refresco++"
                        this.totalCantidadTipoProducto[13] += this.totalCantidadProducto[i]; //"Refresco Mediano++"
                        break;
                    case "Refresco Grande":
                        this.totalCantidadTipoProducto[11] += this.totalCantidadProducto[i]; //"Refresco++"
                        this.totalCantidadTipoProducto[14] += this.totalCantidadProducto[i]; //"Refresco Grande++"
                        break;
                    case "Botella de Agua":
                        this.totalCantidadTipoProducto[15] += this.totalCantidadProducto[i]; //"Agua++"
                        break;
                    case "Chocolate":
                        this.totalCantidadTipoProducto[16] += this.totalCantidadProducto[i]; //"Agua++"
                        break;
                    case "Combo #1":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[4] += this.totalCantidadProducto[i]; //"Popcorn Mediano++"
                        this.totalCantidadTipoProducto[5] += this.totalCantidadProducto[i]; //"Popcorn Mediano Regular++"
                        this.totalCantidadTipoProducto[11] += this.totalCantidadProducto[i]; //"Refresco++"
                        this.totalCantidadTipoProducto[14] += this.totalCantidadProducto[i]; //"Refresco Grande++"
                        break;
                    case "Combo #1 Acaramelado":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[4] += this.totalCantidadProducto[i]; //"Popcorn Mediano++"
                        this.totalCantidadTipoProducto[6] += this.totalCantidadProducto[i]; //"Popcorn Mediano Acaramelado++"
                        this.totalCantidadTipoProducto[11] += this.totalCantidadProducto[i]; //"Refresco++"
                        this.totalCantidadTipoProducto[14] += this.totalCantidadProducto[i]; //"Refresco Grande++"
                        break;
                    case "Combo #2":
                        this.totalCantidadTipoProducto[10] += this.totalCantidadProducto[i]; //"Hot Dog++"
                        this.totalCantidadTipoProducto[11] += this.totalCantidadProducto[i]; //"Refresco++"
                        this.totalCantidadTipoProducto[14] += this.totalCantidadProducto[i]; //"Refresco Grande++"
                        break;
                    case "Combo #3":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[7] += this.totalCantidadProducto[i]; //"Popcorn Grande+"
                        this.totalCantidadTipoProducto[8] += this.totalCantidadProducto[i]; //"Popcorn Grande Regular++"
                        this.totalCantidadTipoProducto[11] += (this.totalCantidadProducto[i]*2); //"Refresco++"
                        this.totalCantidadTipoProducto[13] += (this.totalCantidadProducto[i]*2); //"Refresco Mediano++"
                        break;
                    case "Combo #3 Acaramelado":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[7] += this.totalCantidadProducto[i]; //"Popcorn Grande+"
                        this.totalCantidadTipoProducto[9] += this.totalCantidadProducto[i]; //"Popcorn Grande Acaramelado++"
                        this.totalCantidadTipoProducto[11] += (this.totalCantidadProducto[i]*2); //"Refresco++"
                        this.totalCantidadTipoProducto[13] += (this.totalCantidadProducto[i]*2); //"Refresco Mediano++"
                        break;
                    case "Combo #3 con Refrescos Grandes":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[7] += this.totalCantidadProducto[i]; //"Popcorn Grande+"
                        this.totalCantidadTipoProducto[8] += this.totalCantidadProducto[i]; //"Popcorn Grande Regular++"
                        this.totalCantidadTipoProducto[11] += (this.totalCantidadProducto[i]*2); //"Refresco++"
                        this.totalCantidadTipoProducto[14] += (this.totalCantidadProducto[i]*2); //"Refresco Grande++"
                        break;
                    case "Combo #3 Acaramelado con Refrescos Grandes":
                        this.totalCantidadTipoProducto[0] += this.totalCantidadProducto[i]; //"Popcorn++"
                        this.totalCantidadTipoProducto[7] += this.totalCantidadProducto[i]; //"Popcorn Grande+"
                        this.totalCantidadTipoProducto[9] += this.totalCantidadProducto[i]; //"Popcorn Grande Acaramelado++"
                        this.totalCantidadTipoProducto[11] += (this.totalCantidadProducto[i]*2); //"Refresco++"
                        this.totalCantidadTipoProducto[14] += (this.totalCantidadProducto[i]*2); //"Refresco Grande++"
                        break;
                    default:
                        break;
                }
            }

        }

    }

    //Método para calcular el costo total vendido por tipo de producto
    public void calcularTotalVentaPorTipoProducto() {
        this.totalVentaTipoProducto = new double[17]; //Inicialización del arreglo
        for (int i=0; i<19; i++) {
            if (totalCantidadProducto[i] > 0) {
                switch (getNombreProducto(i)) {
                    case "Popcorn Chico":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*1.25; //"Popcorn++"
                        this.totalVentaTipoProducto[1] += this.totalCantidadProducto[i]*1.25; //"Popcorn Chico++"
                        this.totalVentaTipoProducto[2] += this.totalCantidadProducto[i]*1.25; //"Popcorn Chico Regular++"
                        break;
                    case "Popcorn Chico Acaramelado":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*1.75; //"Popcorn++"
                        this.totalVentaTipoProducto[1] += this.totalCantidadProducto[i]*1.75; //"Popcorn Chico++"
                        this.totalVentaTipoProducto[3] += this.totalCantidadProducto[i]*1.75; //"Popcorn Chico Acaramelado++"
                        break;
                    case "Popcorn Mediano":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*2.00; //"Popcorn++"
                        this.totalVentaTipoProducto[4] += this.totalCantidadProducto[i]*2.00; //"Popcorn Mediano++"
                        this.totalVentaTipoProducto[5] += this.totalCantidadProducto[i]*2.00; //"Popcorn Mediano Regular++"
                        break;
                    case "Popcorn Mediano Acaramelado":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*2.50; //"Popcorn++"
                        this.totalVentaTipoProducto[4] += this.totalCantidadProducto[i]*2.50; //"Popcorn Mediano++"
                        this.totalVentaTipoProducto[6] += this.totalCantidadProducto[i]*2.50; //"Popcorn Mediano Acaramelado++"
                        break;
                    case "Popcorn Grande":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*3.00; //"Popcorn++"
                        this.totalVentaTipoProducto[7] += this.totalCantidadProducto[i]*3.00; //"Popcorn Grande+"
                        this.totalVentaTipoProducto[8] += this.totalCantidadProducto[i]*3.00; //"Popcorn Grande Regular++"
                        break;
                    case "Popcorn Grande Acaramelado":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*3.50; //"Popcorn++"
                        this.totalVentaTipoProducto[7] += this.totalCantidadProducto[i]*3.50; //"Popcorn Grande+"
                        this.totalVentaTipoProducto[9] += this.totalCantidadProducto[i]*3.50; //"Popcorn Grande Acaramelado++"
                        break;
                    case "Hot Dog":
                        this.totalVentaTipoProducto[10] += this.totalCantidadProducto[i]*2.50; //"Hot Dog++"
                        break;
                    case "Refresco Pequeño":
                        this.totalVentaTipoProducto[11] += this.totalCantidadProducto[i]*1.30; //"Refresco++"
                        this.totalVentaTipoProducto[12] += this.totalCantidadProducto[i]*1.30; //"Refresco Pequeño++"
                        break;
                    case "Refresco Mediano":
                        this.totalVentaTipoProducto[11] += this.totalCantidadProducto[i]*2.00; //"Refresco++"
                        this.totalVentaTipoProducto[13] += this.totalCantidadProducto[i]*2.00; //"Refresco Mediano++"
                        break;
                    case "Refresco Grande":
                        this.totalVentaTipoProducto[11] += this.totalCantidadProducto[i]*2.75; //"Refresco++"
                        this.totalVentaTipoProducto[14] += this.totalCantidadProducto[i]*2.75; //"Refresco Grande++"
                        break;
                    case "Botella de Agua":
                        this.totalVentaTipoProducto[15] += this.totalCantidadProducto[i]*1.50; //"Agua++"
                        break;
                    case "Chocolate":
                        this.totalVentaTipoProducto[16] += this.totalCantidadProducto[i]*1.75; //"Agua++"
                        break;
                    case "Combo #1":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*1.875; //"Popcorn++"
                        this.totalVentaTipoProducto[4] += this.totalCantidadProducto[i]*1.875; //"Popcorn Mediano++"
                        this.totalVentaTipoProducto[5] += this.totalCantidadProducto[i]*1.875; //"Popcorn Mediano Regular++"
                        this.totalVentaTipoProducto[11] += this.totalCantidadProducto[i]*2.625; //"Refresco++"
                        this.totalVentaTipoProducto[14] += this.totalCantidadProducto[i]*2.625; //"Refresco Grande++"
                        break;
                    case "Combo #1 Acaramelado":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*2.375; //"Popcorn++"
                        this.totalVentaTipoProducto[4] += this.totalCantidadProducto[i]*2.375; //"Popcorn Mediano++"
                        this.totalVentaTipoProducto[6] += this.totalCantidadProducto[i]*2.375; //"Popcorn Mediano Acaramelado++"
                        this.totalVentaTipoProducto[11] += this.totalCantidadProducto[i]*2.625; //"Refresco++"
                        this.totalVentaTipoProducto[14] += this.totalCantidadProducto[i]*2.625; //"Refresco Grande++"
                        break;
                    case "Combo #2":
                        this.totalVentaTipoProducto[10] += this.totalCantidadProducto[i]*2.375; //"Hot Dog++"
                        this.totalVentaTipoProducto[11] += this.totalCantidadProducto[i]*2.625; //"Refresco++"
                        this.totalVentaTipoProducto[14] += this.totalCantidadProducto[i]*2.625; //"Refresco Grande++"
                        break;
                    case "Combo #3":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*2.90; //"Popcorn++"
                        this.totalVentaTipoProducto[7] += this.totalCantidadProducto[i]*2.90; //"Popcorn Grande+"
                        this.totalVentaTipoProducto[8] += this.totalCantidadProducto[i]*2.90; //"Popcorn Grande Regular++"
                        this.totalVentaTipoProducto[11] += (this.totalCantidadProducto[i]*2)*1.95; //"Refresco++"
                        this.totalVentaTipoProducto[13] += (this.totalCantidadProducto[i]*2)*1.95; //"Refresco Mediano++"
                        break;
                    case "Combo #3 Acaramelado":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*3.40; //"Popcorn++"
                        this.totalVentaTipoProducto[7] += this.totalCantidadProducto[i]*3.40; //"Popcorn Grande+"
                        this.totalVentaTipoProducto[9] += this.totalCantidadProducto[i]*3.40; //"Popcorn Grande Acaramelado++"
                        this.totalVentaTipoProducto[11] += (this.totalCantidadProducto[i]*2)*1.95; //"Refresco++"
                        this.totalVentaTipoProducto[13] += (this.totalCantidadProducto[i]*2)*1.95; //"Refresco Mediano++"
                        break;
                    case "Combo #3 con Refrescos Grandes":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*2.90; //"Popcorn++"
                        this.totalVentaTipoProducto[7] += this.totalCantidadProducto[i]*2.90; //"Popcorn Grande+"
                        this.totalVentaTipoProducto[8] += this.totalCantidadProducto[i]*2.90; //"Popcorn Grande Regular++"
                        this.totalVentaTipoProducto[11] += (this.totalCantidadProducto[i]*2)*2.70; //"Refresco++"
                        this.totalVentaTipoProducto[14] += (this.totalCantidadProducto[i]*2)*2.70; //"Refresco Grande++"
                        break;
                    case "Combo #3 Acaramelado con Refrescos Grandes":
                        this.totalVentaTipoProducto[0] += this.totalCantidadProducto[i]*3.40; //"Popcorn++"
                        this.totalVentaTipoProducto[7] += this.totalCantidadProducto[i]*3.40; //"Popcorn Grande+"
                        this.totalVentaTipoProducto[9] += this.totalCantidadProducto[i]*3.40; //"Popcorn Grande Acaramelado++"
                        this.totalVentaTipoProducto[11] += (this.totalCantidadProducto[i]*2)*2.70; //"Refresco++"
                        this.totalVentaTipoProducto[14] += (this.totalCantidadProducto[i]*2)*2.70; //"Refresco Grande++"
                        break;
                    default:
                        break;
                }
            }

        }

    }

    //Método que muestra en pantalla el detalle de total de ventas por tipo de producto
    public void showTotalVentasPorProducto() {
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃                  CAFE DE CINE UNIVERSITARIO                 ┃");
        System.out.println("\t┃          REPORTE DE TOTAL DE VENTAS POR PRODUCTO            ┃");
        System.out.println("\t┠──────────────────────┬───────────────┬──────────────────────┨");
        System.out.println("\t┠──────────────────────┼───────────────┼──────────────────────┨");
        System.out.println("\t┃       PRODUCTO       |   CANTIDAD    |      VENTA TOTAL     ┃");
        System.out.println("\t┠──────────────────────┼───────────────┼──────────────────────┨");
        System.out.format("\t┃ Popcorn              | %-5d         | B/.%-9.2f         ┃%n", this.getTotalCantidadTipoProducto(0), this.getTotalVentaTipoProducto(0));
        System.out.format("\t┃  ┣━ Chico            |  ┣━ %-5d     |  ┣━ B/.%-9.2f     ┃%n", this.getTotalCantidadTipoProducto(1), this.getTotalVentaTipoProducto(1));
        System.out.format("\t┃  ┃   ┣━ Regular      |  ┃   ┣━ %-5d |  ┃   ┣━ B/.%-9.2f ┃%n", this.getTotalCantidadTipoProducto(2), this.getTotalVentaTipoProducto(2));
        System.out.format("\t┃  ┃   ┗━ Acaramelado  |  ┃   ┗━ %-5d |  ┃   ┗━ B/.%-9.2f ┃%n", this.getTotalCantidadTipoProducto(3), this.getTotalVentaTipoProducto(3));
        System.out.format("\t┃  ┣━ Mediano          |  ┣━ %-5d     |  ┣━ B/.%-9.2f     ┃%n", this.getTotalCantidadTipoProducto(4), this.getTotalVentaTipoProducto(4));
        System.out.format("\t┃  ┃   ┣━ Regular      |  ┃   ┣━ %-5d |  ┃   ┣━ B/.%-9.2f ┃%n", this.getTotalCantidadTipoProducto(5), this.getTotalVentaTipoProducto(5));
        System.out.format("\t┃  ┃   ┗━ Acaramelado  |  ┃   ┗━ %-5d |  ┃   ┗━ B/.%-9.2f ┃%n", this.getTotalCantidadTipoProducto(6), this.getTotalVentaTipoProducto(6));
        System.out.format("\t┃  ┗━ Grande           |  ┗━ %-5d     |  ┗━ B/.%-9.2f     ┃%n", this.getTotalCantidadTipoProducto(7), this.getTotalVentaTipoProducto(7));
        System.out.format("\t┃      ┣━ Regular      |      ┣━ %-5d |      ┣━ B/.%-9.2f ┃%n", this.getTotalCantidadTipoProducto(8), this.getTotalVentaTipoProducto(8));
        System.out.format("\t┃      ┗━ Acaramelado  |      ┗━ %-5d |      ┗━ B/.%-9.2f ┃%n", this.getTotalCantidadTipoProducto(9), this.getTotalVentaTipoProducto(9));
        System.out.println("\t┠──────────────────────┼───────────────┼──────────────────────┨");
        System.out.format("\t┃ Hot Dog              | %-5d         | B/.%-9.2f         ┃%n", this.getTotalCantidadTipoProducto(10), this.getTotalVentaTipoProducto(10));
        System.out.println("\t┠──────────────────────┼───────────────┼──────────────────────┨");
        System.out.format("\t┃ Refresco             | %-5d         | B/.%-9.2f         ┃%n", this.getTotalCantidadTipoProducto(11), this.getTotalVentaTipoProducto(11));
        System.out.format("\t┃  ┣━ Pequeño          |  ┣━ %-5d     |  ┣━ B/.%-9.2f     ┃%n", this.getTotalCantidadTipoProducto(12), this.getTotalVentaTipoProducto(12));
        System.out.format("\t┃  ┣━ Mediano          |  ┣━ %-5d     |  ┣━ B/.%-9.2f     ┃%n", this.getTotalCantidadTipoProducto(13), this.getTotalVentaTipoProducto(13));
        System.out.format("\t┃  ┗━ Grande           |  ┗━ %-5d     |  ┗━ B/.%-9.2f     ┃%n", this.getTotalCantidadTipoProducto(14), this.getTotalVentaTipoProducto(14));
        System.out.println("\t┠──────────────────────┼───────────────┼──────────────────────┨");
        System.out.format("\t┃ Botella de Agua      | %-5d         | B/.%-9.2f         ┃%n", this.getTotalCantidadTipoProducto(15), this.getTotalVentaTipoProducto(15));
        System.out.println("\t┠──────────────────────┼───────────────┼──────────────────────┨");
        System.out.format("\t┃ Chocolate            | %-5d         | B/.%-9.2f         ┃%n", this.getTotalCantidadTipoProducto(16), this.getTotalVentaTipoProducto(16));
        System.out.println("\t┠──────────────────────┴───────────────┴──────────────────────┨");
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
    }

    //Método que muestra en pantalla el detalle de los gran totales recaudados por la cafetería
    public void showTotalRecaudado(){
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃         CAFE DE CINE UNIVERSITARIO          ┃");
        System.out.println("\t┃      REPORTE DE GRAN TOTALES FACTURADOS     ┃");
        System.out.println("\t┠─────────────────────────────────────────────┨");
        System.out.println("\t┠─────────────────────────┬───────────────────┨");
        System.out.println("\t┃     TIPO DE TOTALES     │  MONTO FACTURADO  ┃");
        System.out.println("\t┠─────────────────────────┼───────────────────┨");
        System.out.format("\t┃  SUBTOTAL RECAUDADO     │   B/.%10.2f   ┃%n", this.totalSubtotalCafeteria);
        System.out.println("\t┠─────────────────────────┼───────────────────┨");
        System.out.format("\t┃  DESCUENTO APLICADO     │ - B/.%10.2f   ┃%n", this.totalDescuentoCafeteria);
        System.out.println("\t┠─────────────────────────┼───────────────────┨");
        System.out.format("\t┃  TOTAL FINAL RECAUDADO  │   B/.%10.2f   ┃%n", this.granTotalCafeteria);
        System.out.println("\t┠─────────────────────────┴───────────────────┨");
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
    }

    //Método que muestra en pantalla el detalle del aporte de cada producto con respecto al Subtotal recaudado por la cafeteria
    public void showAporteCadaProducto(){
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃            CAFE DE CINE UNIVERSITARIO            ┃");
        System.out.println("\t┃         APORTE POR CADA TIPO DE PRODUCTO         ┃");
        System.out.println("\t┠──────────────────────────────────────────────────┨");
        System.out.println("\t┠──────────────────────────────────────────────────┨");
        System.out.println("\t┃                        GRAN SUBTOTAL FACTURADO   ┃");
        System.out.format("\t┃                                  B/.%10.2f   ┃%n", this.totalSubtotalCafeteria);
        System.out.println("\t┠────────────────────┬────────────────┬────────────┨");
        System.out.println("\t┃      PRODUCTO      |   FACTURADO    |   APORTE   ┃");
        System.out.println("\t┠────────────────────┼────────────────┼────────────┨");
        System.out.format("\t┃  POPCORN           |  B/.%9.2f  |  %6.2f%%   ┃%n", this.getTotalVentaTipoProducto(0), ((this.getTotalVentaTipoProducto(0)/this.totalSubtotalCafeteria)*100));
        System.out.format("\t┃  HOT DOG           |  B/.%9.2f  |  %6.2f%%   ┃%n", this.getTotalVentaTipoProducto(10), ((this.getTotalVentaTipoProducto(10)/this.totalSubtotalCafeteria)*100));
        System.out.format("\t┃  REFRESCO          |  B/.%9.2f  |  %6.2f%%   ┃%n", this.getTotalVentaTipoProducto(11), ((this.getTotalVentaTipoProducto(11)/this.totalSubtotalCafeteria)*100));
        System.out.format("\t┃  BOTELLA DE AGUA   |  B/.%9.2f  |  %6.2f%%   ┃%n", this.getTotalVentaTipoProducto(15), ((this.getTotalVentaTipoProducto(15)/this.totalSubtotalCafeteria)*100));
        System.out.format("\t┃  CHOCOLATE         |  B/.%9.2f  |  %6.2f%%   ┃%n", this.getTotalVentaTipoProducto(16), ((this.getTotalVentaTipoProducto(16)/this.totalSubtotalCafeteria)*100));
        System.out.println("\t┠────────────────────┴────────────────┴────────────┨");
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
    }
}
