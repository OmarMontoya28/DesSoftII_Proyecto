import java.util.ArrayList;
import static constantes.NombreProductos.*;
import static constantes.PrecioProductos.*;

public class ListaFacturas {
    //Atributos
    private double totalSubtotalFactura;
    private double totalDescuentoFactura;
    private double granTotalFactura;
    private int[] totalCantidadProducto; //Guarda las cantidades totales vendidas por cada producto de todas las facturas en la lista
    private ArrayList<Factura> listaFacturas = new ArrayList<>(); //ArrayList para guardar todos los objetos de la clase Factura

    public double getTotalSubtotalFactura() {
        return totalSubtotalFactura;
    }

    public double getTotalDescuentoFactura() {
        return totalDescuentoFactura;
    }

    public double getGranTotalFactura() {
        return granTotalFactura;
    }

    //Método Getter totalCantidadFactura;
    public int[] getTotalCantidadProducto() {
        return totalCantidadProducto;
    }

    //Método para ingresarle facturas al ArrayList
    public void finalizarFactura(int[] cantidadProductoParametro, boolean jubilado){
        Factura factura = new Factura(cantidadProductoParametro, jubilado); //Instancia Clase Factura

        listaFacturas.add(factura); //Agregar factura al ArrayList

        //Imprimir Factura en Pantalla
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃                CAFE DE CINE UNIVERSITARIO                ┃");
        System.out.println("\t┃                   FACTURA ELECTRONICA                    ┃");
        System.out.println("\t┠──────────────────────────────────┬──────────┬────────────┨");
        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
        System.out.println("\t┃             PRODUCTO             | CANTIDAD |   COSTO    ┃");
        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");

        for (int i=0;i<19;i++) { //Ciclo para recorrer el arreglo que contiene las cantidades por producto de la factura

            if(factura.getCantidadProductoFactura(i) > 0) { //Imprimir solo los productos que se han agregado a la factura

                switch (getNombreProducto(i)) { //Formato de impresión de los combos en la factura
                    case "Combo #1":
                        System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #1", factura.getCantidadProductoFactura(i), (getPrecioProducto(i)*factura.getCantidadProductoFactura(i)));
                        System.out.println("\t┃ (x1) Popcorn Mediano             |          |            ┃");
                        System.out.println("\t┃ (x1) Refresco Grande             |          |            ┃");
                        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                        break;
                    case "Combo #1 Acaramelado":
                        System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #1", factura.getCantidadProductoFactura(i), (getPrecioProducto(i)*factura.getCantidadProductoFactura(i)));
                        System.out.println("\t┃ (x1) Popcorn Mediano Acaramelado |          |            ┃");
                        System.out.println("\t┃ (x1) Refresco Grande             |          |            ┃");
                        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                        break;
                    case "Combo #2":
                        System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #2", factura.getCantidadProductoFactura(i), (getPrecioProducto(i)*factura.getCantidadProductoFactura(i)));
                        System.out.println("\t┃ (x1) Hot Dog                     |          |            ┃");
                        System.out.println("\t┃ (x1) Refresco Grande             |          |            ┃");
                        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                        break;
                    case "Combo #3":
                        System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #3", factura.getCantidadProductoFactura(i), (getPrecioProducto(i)*factura.getCantidadProductoFactura(i)));
                        System.out.println("\t┃ (x1) Popcorn Grande              |          |            ┃");
                        System.out.println("\t┃ (x2) Refrescos Medianos          |          |            ┃");
                        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                        break;
                    case "Combo #3 Acaramelado":
                        System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #3", factura.getCantidadProductoFactura(i), (getPrecioProducto(i)*factura.getCantidadProductoFactura(i)));
                        System.out.println("\t┃ (x1) Popcorn Grande Acaramelado  |          |            ┃");
                        System.out.println("\t┃ (x2) Refrescos Medianos          |          |            ┃");
                        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                        break;
                    case "Combo #3 con Refrescos Grandes":
                        System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #3", factura.getCantidadProductoFactura(i), (getPrecioProducto(i)*factura.getCantidadProductoFactura(i)));
                        System.out.println("\t┃ (x1) Popcorn Grande              |          |            ┃");
                        System.out.println("\t┃ (x2) Refrescos Grandes           |          |            ┃");
                        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                        break;
                    case "Combo #3 Acaramelado con Refrescos Grandes":
                        System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #3", factura.getCantidadProductoFactura(i), (getPrecioProducto(i)*factura.getCantidadProductoFactura(i)));
                        System.out.println("\t┃ (x1) Popcorn Grande Acaramelado  |          |            ┃");
                        System.out.println("\t┃ (x2) Refrescos Grandes           |          |            ┃");
                        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                        break;
                    default: //Formato de impresión del resto de productos disponibles
                        System.out.format("\t┃ %-32s | %8d | B/.%7.2f ┃%n", getNombreProducto(i), factura.getCantidadProductoFactura(i), (getPrecioProducto(i)*factura.getCantidadProductoFactura(i)));
                        System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                        break;
                }
            }
        }
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╅──────────┼────────────┨");
         System.out.format("\t                                   ┃ SUBTOTAL | B/.%7.2f ┃%n", factura.getSubtotalFactura());
         System.out.format("\t                                   ┃ DESC.20%% | B/.%7.2f ┃%n", factura.getDescuentoFactura());
        System.out.println("\t                                   ┠──────────┼────────────┨");
         System.out.format("\t                                   ┃ TOTAL    | B/.%7.2f ┃%n", (factura.getTotalFactura()));
        System.out.println("\t                                   ┗━━━━━━━━━━┷━━━━━━━━━━━━┛");
        System.out.println("\n");
    }

    //Método para imprimir la lista de todas las facturas procesadas
    public void showListaFacturas() {
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃               CAFE DE CINE UNIVERSITARIO                 ┃");
        System.out.println("\t┃        LISTA DE FACTURAS DE PEDIDOS PROCESADOS           ┃");

        for (int i=0;i<listaFacturas.size();i++) { //Ciclo para recorrer el Arraylist que contiene las facturas
            System.out.println("\t┃──────────────────────────────────────────────────────────┨");
            System.out.println("\t┠──────────────────────────────────────────────────────────┨");
            System.out.format("\t┃                      FACTURA #%03d                        ┃%n", (i+1));
            System.out.println("\t┠──────────────────────────────────┬──────────┬────────────┨");
            System.out.println("\t┃             PRODUCTO             | CANTIDAD |   COSTO    ┃");
            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");

            for (int j=0;j<19;j++) { //Ciclo para recorrer los datos de cada factura individual

                if(listaFacturas.get(i).getCantidadProductoFactura(j) > 0) { //Imprimir solo los productos que se han agregado a cada factura individualmente

                    switch (getNombreProducto(j)) { //Formato de impresión de los combos en la factura
                        case "Combo #1":
                            System.out.format("\t┃ %-32s | %8d | B/.%7.2f ┃%n", "Combo #1", listaFacturas.get(i).getCantidadProductoFactura(j), (getPrecioProducto(i)*listaFacturas.get(i).getCantidadProductoFactura(j)));
                            System.out.println("\t┃ (x1) Popcorn Mediano             |          |            ┃");
                            System.out.println("\t┃ (x1) Refresco Grande             |          |            ┃");
                            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                            break;
                        case "Combo #1 Acaramelado":
                            System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #1", listaFacturas.get(i).getCantidadProductoFactura(j), (getPrecioProducto(i)*listaFacturas.get(i).getCantidadProductoFactura(j)));
                            System.out.println("\t┃ (x1) Popcorn Mediano Acaramelado |          |            ┃");
                            System.out.println("\t┃ (x1) Refresco Grande             |          |            ┃");
                            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                            break;
                        case "Combo #2":
                            System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #2", listaFacturas.get(i).getCantidadProductoFactura(j), (getPrecioProducto(i)*listaFacturas.get(i).getCantidadProductoFactura(j)));
                            System.out.println("\t┃ (x1) Hot Dog                     |          |            ┃");
                            System.out.println("\t┃ (x1) Refresco Grande             |          |            ┃");
                            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                            break;
                        case "Combo #3":
                            System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #3", listaFacturas.get(i).getCantidadProductoFactura(j), (getPrecioProducto(i)*listaFacturas.get(i).getCantidadProductoFactura(j)));
                            System.out.println("\t┃ (x1) Popcorn Grande              |          |            ┃");
                            System.out.println("\t┃ (x2) Refrescos Medianos          |          |            ┃");
                            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                            break;
                        case "Combo #3 Acaramelado":
                            System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #3", listaFacturas.get(i).getCantidadProductoFactura(j), (getPrecioProducto(i)*listaFacturas.get(i).getCantidadProductoFactura(j)));
                            System.out.println("\t┃ (x1) Popcorn Grande Acaramelado  |          |            ┃");
                            System.out.println("\t┃ (x2) Refrescos Medianos          |          |            ┃");
                            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                            break;
                        case "Combo #3 con Refrescos Grandes":
                            System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #3", listaFacturas.get(i).getCantidadProductoFactura(j), (getPrecioProducto(i)*listaFacturas.get(i).getCantidadProductoFactura(j)));
                            System.out.println("\t┃ (x1) Popcorn Grande              |          |            ┃");
                            System.out.println("\t┃ (x2) Refrescos Grandes           |          |            ┃");
                            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                            break;
                        case "Combo #3 Acaramelado con Refrescos Grandes":
                            System.out.format("\t┃ %-32s | %8d | B/.%7.2f |%n", "Combo #3", listaFacturas.get(i).getCantidadProductoFactura(j), (getPrecioProducto(i)*listaFacturas.get(i).getCantidadProductoFactura(j)));
                            System.out.println("\t┃ (x1) Popcorn Grande Acaramelado  |          |            ┃");
                            System.out.println("\t┃ (x2) Refrescos Grandes           |          |            ┃");
                            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                            break;
                        default: //Formato de impresión del resto de productos facturados
                            System.out.format("\t┃ %-32s | %8d | B/.%7.2f ┃%n", getNombreProducto(j), listaFacturas.get(i).getCantidadProductoFactura(j), (getPrecioProducto(j)*listaFacturas.get(i).getCantidadProductoFactura(j)));
                            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
                            break;
                    }
                }
            }
            System.out.println("\t┠──────────────────────────────────┼──────────┼────────────┨");
            System.out.println("\t┠──────────────────────────────────┴──────────┼────────────┨");
            System.out.format("\t┃                                    SUBTOTAL | B/.%7.2f ┃%n", listaFacturas.get(i).getSubtotalFactura());
            System.out.format("\t┃                                    DESC.20%% | B/.%7.2f ┃%n", listaFacturas.get(i).getDescuentoFactura());
            System.out.println("\t┠─────────────────────────────────────────────┼────────────┨");
            System.out.format("\t┃                                       TOTAL | B/.%7.2f ┃%n", listaFacturas.get(i).getTotalFactura());
            System.out.println("\t┠─────────────────────────────────────────────┴────────────┨");
        }
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        System.out.println();
    }

    //Método para calcular las cantidades totales de cada tipo de producto en la lista de facturas
    public void calcularTotalCantidadProducto(){
        totalCantidadProducto = new int[19]; //Inicialización del arreglo
        for (int i=0; i<listaFacturas.size(); i++) { //Recorrer toda la lista de facturas
            for (int j=0; j<19; j++) { //Recorrer cada factura individualmente y sumar las cantidades vendidas por cada producto
                this.totalCantidadProducto[j] += listaFacturas.get(i).getCantidadProductoFactura(j);
            }
        }
    }

    //Método para sumar los subtotales de todas las facturas procesadas
    public void calcularTotalSubtotalFactura(){
        this.totalSubtotalFactura = 0;
        for (int i=0; i<listaFacturas.size(); i++) { //Recorrer toda la lista de facturas
            this.totalSubtotalFactura += listaFacturas.get(i).getSubtotalFactura();
        }
    }

    //Método para sumar los descuentos de todas las facturas procesadas
    public void calcularTotalDescuentoFactura(){
        this.totalDescuentoFactura = 0;
        for (int i=0; i<listaFacturas.size(); i++) { //Recorrer toda la lista de facturas
            this.totalDescuentoFactura += listaFacturas.get(i).getDescuentoFactura();
        }
    }

    //Método para sumar los totales finales de todas las factura procesada
    public void calcularGranTotalFactura(){
        this.granTotalFactura = 0;
        for (int i=0; i<listaFacturas.size(); i++) { //Recorrer toda la lista de facturas
            this.granTotalFactura += listaFacturas.get(i).getTotalFactura();
        }
    }

}
