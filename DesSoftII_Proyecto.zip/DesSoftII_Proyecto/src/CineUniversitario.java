import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CineUniversitario {
    public static void main(String[] args) {
        //Instancia BufferedReader
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        //Clase que contiene la lista de precios y productos del menu
        MenuProductos menuProductos = new MenuProductos();

        //Clase que contiene la lista de todas las facturas procesadas
        ListaFacturas listaFacturas = new ListaFacturas();

        //Clase que contiene los cálculos y valores de los totales por producto
        TotalVentasPorProducto totalVentasPorProducto;

        //Clase que contiene el proceso de salida del programa
        SalirPrograma salirPrograma = new SalirPrograma();

        //Variable para controlar el ciclo del programa
        boolean salirMenuPrincipal = false;

        //Mostrar Mensaje de Bienvenida del Programa
        System.out.println("Bienvenido al Sistema de Ventas del Cine Universitario");

        do {
            //Mostrar Menu Principal de Consultas
            System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
            System.out.println("\t┃     CAFE DE CINE UNIVERSITARIO     ┃");
            System.out.println("\t┃           MENU PRINCIPAL           ┃");
            System.out.println("\t┠────────────────────────────────────┨");
            System.out.println("\t┠─────┬──────────────────────────────┨");
            System.out.println("\t┃ (1) │ Ver menu de productos        ┃");
            System.out.println("\t┠─────┼──────────────────────────────┨");
            System.out.println("\t┃ (2) │ Facturar pedido              ┃");
            System.out.println("\t┠─────┼──────────────────────────────┨");
            System.out.println("\t┃ (3) │ Ver facturas procesadas      ┃");
            System.out.println("\t┠─────┼──────────────────────────────┨");
            System.out.println("\t┃ (4) │ Total de ventas por producto ┃");
            System.out.println("\t┠─────┼──────────────────────────────┨");
            System.out.println("\t┃ (5) │ Total recaudado              ┃");
            System.out.println("\t┠─────┼──────────────────────────────┨");
            System.out.println("\t┃ (6) │ Aporte de cada producto      ┃");
            System.out.println("\t┠─────┼──────────────────────────────┨");
            System.out.println("\t┃ (0) │ Salir del sistema            ┃");
            System.out.println("\t┠─────┴──────────────────────────────┨");
            System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
            System.out.print("\tSeleccione su consulta deseada: ");
            try { //try/catch para el uso de BufferedReader
                int consulta = Integer.parseInt(br.readLine()); //Consulta escogida por el usuario
                switch (consulta) {
                    case 1: //Ver menu de productos
                        menuProductos.mostrarMenuProductos();
                        break;
                    case 2: //Facturar pedido
                        FacturarPedido facturarPedido = new FacturarPedido(); //Clase que contiene los procesos para facturar un pedido
                        facturarPedido.iniciarPedido(); //Proceso para escoger los productos y luego procesar la factura
                        if (facturarPedido.isProcesarFactura()) { //Procesa la factura del pedido solo si el usuario eligió esa opción
                            listaFacturas.finalizarFactura(facturarPedido.getCantidadProducto(), facturarPedido.isJubilado()); //Finalizar el pedido y procesar la factura
                        }
                        break;
                    case 3: //Imprimir todas las facturas procesadas
                        listaFacturas.showListaFacturas();
                        break;
                    case 4: //Total de ventas por producto
                        listaFacturas.calcularTotalCantidadProducto(); //Recorrer la lista de facturas y calcular el total de las cantidades facturadas
                        totalVentasPorProducto = new TotalVentasPorProducto(listaFacturas.getTotalCantidadProducto()); //Instancia Clase TotalVentasProProducto
                        totalVentasPorProducto.calcularTotalCantidadPorTipoProducto(); //Generar las cantidades totales por tipo de producto
                        totalVentasPorProducto.calcularTotalVentaPorTipoProducto(); //Generar las ventas totales por tipo de producto
                        totalVentasPorProducto.showTotalVentasPorProducto(); //Imprimir el detalle de las ventas por tipo de producto
                        break;
                    case 5: //Total Recaudado
                        listaFacturas.calcularTotalSubtotalFactura(); //Recorrer la lista de facturas y calcular el total de las cantidades facturadas
                        listaFacturas.calcularTotalDescuentoFactura(); //Generar las cantidades
                        listaFacturas.calcularGranTotalFactura();
                        totalVentasPorProducto = new TotalVentasPorProducto(listaFacturas.getTotalSubtotalFactura(), listaFacturas.getTotalDescuentoFactura(), listaFacturas.getGranTotalFactura()); //Instancia Clase TotalVentasProProducto
                        totalVentasPorProducto.showTotalRecaudado();
                        break;
                    case 6: //Aporte de Cada Producto
                        listaFacturas.calcularTotalCantidadProducto(); //Recorrer la lista de facturas y calcular el total de las cantidades facturadas
                        listaFacturas.calcularTotalSubtotalFactura(); //Recorrer la lista de facturas y calcular el total de las cantidades facturadas
                        totalVentasPorProducto = new TotalVentasPorProducto(listaFacturas.getTotalCantidadProducto(), listaFacturas.getTotalSubtotalFactura());
                        totalVentasPorProducto.calcularTotalVentaPorTipoProducto(); //Generar las ventas totales por tipo de producto
                        totalVentasPorProducto.showAporteCadaProducto();
                        break;
                    case 0: //Salir del sistema
                        salirMenuPrincipal = salirPrograma.salirDelSistema();
                        break;
                    default: //Consulta ingresada invalida
                        System.out.println("\tPor favor introduzca una consulta valida");
                        System.out.println("\tInténtelo de nuevo");
                }
            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo de nuevo");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");;
                System.out.println("\tInténtelo de nuevo");
            }
        } while (!salirMenuPrincipal);
    }
}