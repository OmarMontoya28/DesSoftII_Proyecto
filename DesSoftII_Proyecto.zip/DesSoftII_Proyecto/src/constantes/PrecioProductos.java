package constantes;

public class PrecioProductos {
    //Arreglo que contiene el precio de los productos utilizados en el programa
    private static final double[] precioProducto = new double[] {
            /*precioProducto[0]*/ 1.25,
            /*precioProducto[1]*/ 1.75,
            /*precioProducto[2]*/ 2.00,
            /*precioProducto[3]*/ 2.50,
            /*precioProducto[4]*/ 3.00,
            /*precioProducto[5]*/ 3.50,
            /*precioProducto[6]*/ 2.50,
            /*precioProducto[7]*/ 1.30,
            /*precioProducto[8]*/ 2.00,
            /*precioProducto[9]*/ 2.75,
            /*precioProducto[10]*/ 1.50,
            /*precioProducto[11]*/ 1.75,
            /*precioProducto[12]*/ 4.50,
            /*precioProducto[13]*/ 5.00,
            /*precioProducto[14]*/ 5.00,
            /*precioProducto[15]*/ 6.80,
            /*precioProducto[16]*/ 7.30,
            /*precioProducto[17]*/ 8.30,
            /*precioProducto[18]*/ 8.80
    };

    //Método para obtener el nombre de algún producto específico
    public static double getPrecioProducto(int i){
        return precioProducto[i];
    }
}
