package constantes;

public class NombreProductos {
    //Arreglo que contiene los nombres de los productos utilizados en el programa
    private static final String[] nombreProducto = new String[] {
            /*nombreProducto[0]*/ "Popcorn Chico",
            /*nombreProducto[1]*/ "Popcorn Chico Acaramelado",
            /*nombreProducto[2]*/ "Popcorn Mediano",
            /*nombreProducto[3]*/ "Popcorn Mediano Acaramelado",
            /*nombreProducto[4]*/ "Popcorn Grande",
            /*nombreProducto[5]*/ "Popcorn Grande Acaramelado",
            /*nombreProducto[6]*/ "Hot Dog",
            /*nombreProducto[7]*/ "Refresco Pequeño",
            /*nombreProducto[8]*/ "Refresco Mediano",
            /*nombreProducto[9]*/ "Refresco Grande",
            /*nombreProducto[10]*/ "Botella de Agua",
            /*nombreProducto[11]*/ "Chocolate",
            /*nombreProducto[12]*/ "Combo #1",
            /*nombreProducto[13]*/ "Combo #1 Acaramelado",
            /*nombreProducto[14]*/ "Combo #2",
            /*nombreProducto[15]*/ "Combo #3",
            /*nombreProducto[16]*/ "Combo #3 Acaramelado",
            /*nombreProducto[17]*/ "Combo #3 con Refrescos Grandes",
            /*nombreProducto[18]*/ "Combo #3 Acaramelado con Refrescos Grandes"
    };

    //Método para obtener el nombre de algún producto específico
    public static String getNombreProducto(int i){
        return nombreProducto[i];
    }
}
