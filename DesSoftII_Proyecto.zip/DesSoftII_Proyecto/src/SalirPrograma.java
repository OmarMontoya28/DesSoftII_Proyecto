import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SalirPrograma {
    //Instancia BufferedReader
    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(isr);

    //Consulta para salir del programa
    public boolean salirDelSistema() {
        boolean salirMenuPrincipalConfirmacion;
        boolean salirMenuPrincipal = false;
        do {
            System.out.println("\tEsta seguro que desea salir?");
            System.out.println("\tEscriba (1): Salir Programa / (0): Volver al menu principal");
            try {
                int respuestaSalirMenuPrincipal = Integer.parseInt(br.readLine());
                if (respuestaSalirMenuPrincipal == 1) {
                    System.out.println("\tGracias por su tiempo. Hasta luego!");
                    salirMenuPrincipalConfirmacion = true;
                    salirMenuPrincipal = true;
                } else if (respuestaSalirMenuPrincipal == 0) {
                    salirMenuPrincipalConfirmacion = true;
                } else {
                    System.out.println("\tHa introducido un valor incorrecto");
                    salirMenuPrincipalConfirmacion = false;
                }
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente\n");
                salirMenuPrincipalConfirmacion = false;
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido\n");
                salirMenuPrincipalConfirmacion = false;
            }
        } while(!salirMenuPrincipalConfirmacion);
        return salirMenuPrincipal;
    }
}
