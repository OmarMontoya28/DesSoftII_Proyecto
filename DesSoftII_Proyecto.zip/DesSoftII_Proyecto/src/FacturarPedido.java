import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class FacturarPedido {
    //Atributos
    private int[] cantidadProducto = new int[15]; //guarda la cantidad de cada producto que se esté agregando a la factura
    private boolean jubilado; //confirma si usuario es jubilado o no
    private boolean procesarFactura; //confirma si usuario eligió procesar la factura o solo volver al menú principal

    //Instancia BufferedReader
    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(isr);

    //Instancia Clase OpcionesFacturarPedido
    OpcionesFacturarPedido opcionesFacturarPedido = new OpcionesFacturarPedido();

    //Método Getter atributo cantidadProducto
    public int[] getCantidadProducto() {
        return this.cantidadProducto;
    }

    //Método Getter atributo jubilado
    public boolean isJubilado(){
        return this.jubilado;
    }

    public boolean isProcesarFactura(){
        return this.procesarFactura;
    }

    //Consulta para facturar un pedido de productos
    public void iniciarPedido() {
        //Variable para controlar el ciclo de facturación
        boolean finalizarFactura = false;
        //Ciclo en caso que usuario ingrese una opción no valida
        do {
            //Mostrar Menu de Productos a Facturar
            System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
            System.out.println("\t┃ CAFE DE CINE UNIVERSITARIO ┃");
            System.out.println("\t┃      FACTURAR PEDIDO       ┃");
            System.out.println("\t┠────────────────────────────┨");
            System.out.println("\t┠─────┬──────────────────────┨");
            System.out.println("\t┃ (1) │ Popcorn              ┃");
            System.out.println("\t┠─────┼──────────────────────┨");
            System.out.println("\t┃ (2) │ Hotdog               ┃");
            System.out.println("\t┠─────┼──────────────────────┨");
            System.out.println("\t┃ (3) │ Refresco             ┃");
            System.out.println("\t┠─────┼──────────────────────┨");
            System.out.println("\t┃ (4) │ Agua                 ┃");
            System.out.println("\t┠─────┼──────────────────────┨");
            System.out.println("\t┃ (5) │ Chocolate            ┃");
            System.out.println("\t┠─────┼──────────────────────┨");
            System.out.println("\t┃ (6) │ Combo                ┃");
            System.out.println("\t┠─────┼──────────────────────┨");
            System.out.println("\t┃ (7) │ Procesar Factura     ┃");
            System.out.println("\t┠─────┼──────────────────────┨");
            System.out.println("\t┃ (0) │ Menu Principal       ┃");
            System.out.println("\t┠─────┴──────────────────────┨");
            System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
            System.out.print("\tEscoja una de las opciones: ");
            //try/catch para el uso de BufferedReader
            try {
                //Producto escogido para agregar a la opcionesFacturarPedido
                int productoSeleccionado = Integer.parseInt(br.readLine());

                switch (productoSeleccionado) {
                    case 1: //Popcorn
                        opcionesFacturarPedido.showOpcionPopcorn();
                        break;
                    case 2: //Hot Dog
                        opcionesFacturarPedido.showOpcionHotDog();
                        break;
                    case 3: //Refresco
                        opcionesFacturarPedido.showOpcionRefresco();
                        break;
                    case 4: //Agua
                        opcionesFacturarPedido.showOpcionAgua();
                        break;
                    case 5: //Chocolate
                        opcionesFacturarPedido.showOpcionChocolate();
                        break;
                    case 6: //Combo
                        opcionesFacturarPedido.showOpcionCombo();
                        break;
                    case 7: //Procesar la factura con los productos agregados
                        opcionesFacturarPedido.respuestaJubilado();
                        this.jubilado = opcionesFacturarPedido.isJubilado();
                        this.cantidadProducto = opcionesFacturarPedido.getCantidadProducto();
                        this.procesarFactura = true;
                        finalizarFactura = true;
                        break;
                    case 0: //Volver al menu principal
                        this.procesarFactura = false;
                        finalizarFactura = true;
                        break;
                    default: //opción ingresada invalida
                        System.out.println("\tHa introduzido una opción incorrecta");
                        System.out.println("\tInténtelo de nuevo");
                }
            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo de nuevo");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");;
                System.out.println("\tInténtelo de nuevo");
            }
        } while (!finalizarFactura);
    }



}
