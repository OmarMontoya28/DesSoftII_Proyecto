import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import static constantes.PrecioProductos.*;

public class OpcionesFacturarPedido {
    //Atributos
    private boolean acaramelado; //confirma si usuario desea Popcorn acaramelado o no
    private boolean jubilado; //confirma si usuario es jubilado o no
    private int cantidad; //guarda el valor de la cantidad de productos a agregar a la opcionesFacturarPedido
    private int tamanoRefresco; //guarda el valor del tamaño de refresco del combo #3: (2) Mediano (3) Grande
    private int[] cantidadProducto = new int[19]; //guarda la cantidad de cada producto que se esté agregando a la factura

    //Instancia BufferedReader
    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(isr);

    //Método Getter atributo cantidadProducto
    public int[] getCantidadProducto() {
        return this.cantidadProducto;
    }

    //Método Getter atributo jubilado
    public boolean isJubilado(){
        return this.jubilado;
    }

    //Método para preguntar al usuario si desea su popcorn acaramelado
    public void respuestaAcaramelado(String tamano){
        System.out.println("\tDesea hacer su Popcorn " + tamano + " acaramelado por $0.50 adicionales?");

        //Variable para control del ciclo
        boolean salirOpcionAcaramelado = false;

        //Ciclo en caso que usuario ingrese una opción no valida
        do {
            System.out.print("\tIngrese (1) Si / (0) No: ");
            //try/catch para el uso de BufferedReader
            try {
                int respuestaAcaramelado = Integer.parseInt(br.readLine());

                if (respuestaAcaramelado == 1) {
                    this.acaramelado = true;
                    salirOpcionAcaramelado = true;
                } else if (respuestaAcaramelado == 0) {
                    this.acaramelado = false;
                    salirOpcionAcaramelado = true;
                } else {
                    System.out.println("\tHa ingresado una opción incorrecta");
                    System.out.println("\tInténtelo nuevamente");
                }

            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");
                System.out.println("\tInténtelo nuevamente");
            }

        } while(!salirOpcionAcaramelado);
    }

    //Método para preguntar al usuario si aplica para descuento de jubilado
    public void respuestaJubilado() {
        System.out.println("\tAplica para descuento de jubilado?");

        //Variable para control del ciclo
        boolean salirRespuestaJubilado = false;

        //Ciclo en caso que usuario ingrese una opción no valida
        do {
            System.out.print("\tIngrese (1) Si / (0) No: ");
            //try/catch para el uso de BufferedReader
            try {
                int respuestaJubilado = Integer.parseInt(br.readLine());

                if (respuestaJubilado == 1) {
                    this.jubilado = true;
                    salirRespuestaJubilado = true;
                } else if (respuestaJubilado == 0) {
                    this.jubilado = false;
                    salirRespuestaJubilado = true;
                } else {
                    System.out.println("\tHa ingresado una opción incorrecta");
                    System.out.println("\tInténtelo nuevamente");
                }
            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");
                System.out.println("\tInténtelo nuevamente");
            }

        } while(!salirRespuestaJubilado);
    }

    //Método para preguntar al usuario cuantos productos desea agregar a la opcionesFacturarPedido
    public void respuestaCantidad(String nombreProducto) {
        System.out.println("\tCuantos " + nombreProducto + " desea facturar?");

        //Variable para control del ciclo
        boolean salirOpcionCantidad = false;

        //Ciclo en caso que usuario ingrese una opción no valida
        do {
            System.out.print("\tIngrese la cantidad: ");
            //try/catch para el uso de BufferedReader
            try {
                cantidad = Integer.parseInt(br.readLine());

                if (cantidad >= 1) {
                    salirOpcionCantidad = true;
                } else {
                    System.out.println("\tHa ingresado una cantidad negativa o nula.");
                    System.out.println("\tIngrese una cantidad valida.");
                }

            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");
                System.out.println("\tInténtelo nuevamente");
            }
        } while(!salirOpcionCantidad);

    }

    //Método para preguntar al usuario si desea cambiar el tamaño de su refresco del combo
    public void respuestaAumentarTamanoRefresco() {
        System.out.println("\tDesea aumentar el tamaño de sus Refrescos Medianos a Grandes por $1.50 adicionales?");

        //Variable para control del ciclo
        boolean salirOpcionAumentarTamanoRefresco = false;

        //Ciclo en caso que usuario ingrese una opción no valida
        do {
            System.out.print("\tIngrese (1) Si / (0) No: ");
            //try/catch para el uso de BufferedReader
            try {
                int respuestaAumentarTamanoRefresco = Integer.parseInt(br.readLine());

                if (respuestaAumentarTamanoRefresco == 1) {
                    tamanoRefresco = 3;
                    salirOpcionAumentarTamanoRefresco = true;
                } else if (respuestaAumentarTamanoRefresco == 0) {
                    tamanoRefresco = 2;
                    salirOpcionAumentarTamanoRefresco = true;
                } else {
                    System.out.println("\tHa ingresado una opción incorrecta");
                    System.out.println("\tInténtelo nuevamente");
                }
            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");
                System.out.println("\tInténtelo nuevamente");
            }

        } while(!salirOpcionAumentarTamanoRefresco);
    }

    //Método para agregar un Popcorn a la opcionesFacturarPedido
    public void showOpcionPopcorn() {
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃ CAFE DE CINE UNIVERSITARIO ┃");
        System.out.println("\t┃      FACTURAR PEDIDO       ┃");
        System.out.println("\t┠────────────────────────────┨");
        System.out.println("\t┠────────────────────────────┨");
        System.out.println("\t┃    OPCIONES DE POPCORN     ┃");
        System.out.println("\t┠─────┬──────────────────────┨");
        System.out.println("\t┃ (1) │ Chico                ┃");
        System.out.println("\t┠─────┼──────────────────────┨");
        System.out.println("\t┃ (2) │ Mediano              ┃");
        System.out.println("\t┠─────┼──────────────────────┨");
        System.out.println("\t┃ (3) │ Grande               ┃");
        System.out.println("\t┠─────┼──────────────────────┨");
        System.out.println("\t┃ (4) │ Cancelar             ┃");
        System.out.println("\t┠─────┴──────────────────────┨");
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");

        boolean salirOpcionPopcorn = false;
        do {
            System.out.print("\tIngrese un tamaño de Popcorn: ");

            try {
                int respuestaOpcionPopcorn = Integer.parseInt(br.readLine());

                switch (respuestaOpcionPopcorn) {
                    case 1: //Popcorn Chico
                        respuestaAcaramelado("Chico");
                        if (acaramelado) {
                            respuestaCantidad("Popcorn Chicos acaramelados");
                            System.out.println("\tHas ingresado " + cantidad + " Popcorn Chico(s) acaramelado(s) a la factura (+$"+((getPrecioProducto(1))*cantidad)+")");
                            this.cantidadProducto[1] += cantidad;
                        } else {
                            respuestaCantidad("Popcorn Chicos");
                            System.out.println("\tHas ingresado " + cantidad + " Popcorn Chico a la factura (+$"+((getPrecioProducto(0))*cantidad)+")");
                            this.cantidadProducto[0] += cantidad;
                        }
                        salirOpcionPopcorn = true;
                        break;
                    case 2: //Popcorn Mediano
                        respuestaAcaramelado("Mediano");
                        if (acaramelado) {
                            respuestaCantidad("Popcorn Medianos acaramelados");
                            System.out.println("\tHas ingresado " + cantidad + " Popcorn Mediano(s) acaramelado(s) a la factura (+$"+((getPrecioProducto(3))*cantidad)+")");
                            this.cantidadProducto[3] += cantidad;
                        } else {
                            respuestaCantidad("Popcorn Medianos");
                            System.out.println("\tHas ingresado " + cantidad + " Popcorn Mediano(s) a la factura (+$"+((getPrecioProducto(2))*cantidad)+")");
                            this.cantidadProducto[2] += cantidad;
                        }
                        salirOpcionPopcorn = true;
                        break;
                    case 3: //Popcorn Grande
                        respuestaAcaramelado("Grande");
                        if (acaramelado) {
                            respuestaCantidad("Popcorn Grandes acaramelados");
                            System.out.println("\tHas ingresado " + cantidad + " Popcorn Grande(s) acaramelado(s) a la factura (+$"+((getPrecioProducto(5))*cantidad)+")");
                            this.cantidadProducto[5] += cantidad;
                        } else {
                            respuestaCantidad("Popcorn Grandes");
                            System.out.println("\tHas ingresado " + cantidad + " Popcorn Grande(s) a la factura (+$"+((getPrecioProducto(4))*cantidad)+")");
                            this.cantidadProducto[4] += cantidad;
                        }
                        salirOpcionPopcorn = true;
                        break;
                    case 4: //Cancelar Producto seleccionado y volver a Menu OpcionesFacturarPedido
                        System.out.println("\tCancelaste la opción de facturar Popcorn");
                        salirOpcionPopcorn = true;
                        break;
                    default: //Opción ingresada invalida
                        System.out.println("\tHa introduzido una opción incorrecta");
                        System.out.println("\tInténtelo nuevamente");
                }
            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");
                System.out.println("\tInténtelo nuevamente");
            }
        //Mientras salirOpcionPopcorn no sea falso
        } while(!salirOpcionPopcorn);
    }

    //Método para agregar un Hot Dog a la opcionesFacturarPedido
    public void showOpcionHotDog() {
        respuestaCantidad("Hot Dogs");
        System.out.println("\tHas ingresado " + cantidad + " Hot Dog(s) a la factura (+$"+((getPrecioProducto(6))*cantidad)+")");
        this.cantidadProducto[6] += cantidad;
    }

    //Método para agregar un Refresco a la opcionesFacturarPedido
    public void showOpcionRefresco() {
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃ CAFE DE CINE UNIVERSITARIO ┃");
        System.out.println("\t┃      FACTURAR PEDIDO       ┃");
        System.out.println("\t┠────────────────────────────┨");
        System.out.println("\t┠────────────────────────────┨");
        System.out.println("\t┃    OPCIONES DE REFRESCO    ┃");
        System.out.println("\t┠─────┬──────────────────────┨");
        System.out.println("\t┃ (1) │ Pequeño              ┃");
        System.out.println("\t┠─────┼──────────────────────┨");
        System.out.println("\t┃ (2) │ Mediano              ┃");
        System.out.println("\t┠─────┼──────────────────────┨");
        System.out.println("\t┃ (3) │ Grande               ┃");
        System.out.println("\t┠─────┼──────────────────────┨");
        System.out.println("\t┃ (4) │ Cancelar             ┃");
        System.out.println("\t┠─────┴──────────────────────┨");
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        boolean salirOpcionRefresco = false;
        do {
            System.out.print("\tIngrese un tamaño de Refresco: ");
            try {
                int respuestaOpcionRefresco = Integer.parseInt(br.readLine());
                switch (respuestaOpcionRefresco) {
                    case 1: //Refresco Pequeño
                        respuestaCantidad("Refresco Pequeños");
                        System.out.println("\tHas ingresado " + cantidad + " Refresco Pequeño(s) a la factura (+$"+((getPrecioProducto(7))*cantidad)+")");
                        salirOpcionRefresco = true;
                        this.cantidadProducto[7] += cantidad;
                        break;
                    case 2: //Refresco Mediano
                        respuestaCantidad("Refresco Medianos");
                        System.out.println("\tHas ingresado "+ cantidad + " Refresco Mediano(s) a la factura (+$"+((getPrecioProducto(8))*cantidad)+")");
                        salirOpcionRefresco = true;
                        this.cantidadProducto[8] += cantidad;
                        break;
                    case 3: //Refresco Grande
                        respuestaCantidad("Refresco Grandes");
                        System.out.println("\tHas ingresado "+ cantidad +" Refresco Grande(s) a la factura (+$"+((getPrecioProducto(9))*cantidad)+")");
                        salirOpcionRefresco = true;
                        this.cantidadProducto[9] += cantidad;
                        break;
                    case 4: //Cancelar Producto seleccionado y volver a Menu OpcionesFacturarPedido
                        System.out.println("\tCancelaste la opción de facturar Refresco");
                        salirOpcionRefresco = true;
                        break;
                    default: //Opción ingresada invalida
                        System.out.println("\tHa introduzido una opción incorrecta");
                        System.out.println("\tInténtelo nuevamente");
                }
            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");
                System.out.println("\tInténtelo nuevamente");
            }
        } while(!salirOpcionRefresco);
    }

    //Método para agregar una Botella de Agua a la opcionesFacturarPedido
    public void showOpcionAgua() {
        respuestaCantidad("Botellas de agua");
        System.out.println("\tHas ingresado " + cantidad + " botella(s) de agua a la factura (+$"+((getPrecioProducto(10))*cantidad)+")");
        this.cantidadProducto[10] += cantidad;
    }

    //Método para agregar un Chocolate a la opcionesFacturarPedido
    public void showOpcionChocolate() {
        respuestaCantidad("Chocolates");
        System.out.println("\tHas ingresado " + cantidad + " chocolate(s) a la factura (+$"+((getPrecioProducto(11))*cantidad)+")");
        this.cantidadProducto[11] += cantidad;
    }

    //Método para agregar un Combo a la opcionesFacturarPedido
    public void showOpcionCombo(){
        System.out.println("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("\t┃   CAFE DE CINE UNIVERSITARIO  ┃");
        System.out.println("\t┃        FACTURAR PEDIDO        ┃");
        System.out.println("\t┠───────────────────────────────┨");
        System.out.println("\t┠───────────────────────────────┨");
        System.out.println("\t┃      OPCIONES DE COMBOS       ┃");
        System.out.println("\t┠─────┬─────────────────────────┨");
        System.out.println("\t┃     │ Combo 1:                ┃");
        System.out.println("\t┃ (1) │ (x1) Popcorn Mediano    ┃");
        System.out.println("\t┃     │ (x1) Refresco Grande    ┃");
        System.out.println("\t┠─────┼─────────────────────────┨");
        System.out.println("\t┃     │ Combo 2:                ┃");
        System.out.println("\t┃ (2) │ (x1) Hot Dog            ┃");
        System.out.println("\t┃     │ (x1) Refresco Grande    ┃");
        System.out.println("\t┠─────┼─────────────────────────┨");
        System.out.println("\t┃     │ Combo 3:                ┃");
        System.out.println("\t┃ (3) │ (x1) Popcorn Grande     ┃");
        System.out.println("\t┃     │ (x2) Refrescos Medianos ┃");
        System.out.println("\t┠─────┼─────────────────────────┨");
        System.out.println("\t┃ (4) │ Cancelar                ┃");
        System.out.println("\t┠─────┴─────────────────────────┨");
        System.out.println("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        boolean salirOpcionCombo = false;
        do {
            System.out.print("\tIngrese un combo a facturar: ");
            try {
                int respuestaOpcionCombo = Integer.parseInt(br.readLine());
                switch (respuestaOpcionCombo) {
                    case 1: //Combo 1
                        respuestaAcaramelado("Mediano");
                        if (acaramelado) {
                            respuestaCantidad("Combos #1 acaramelados");
                            System.out.println("\tHas ingresado " + cantidad + " Combo(s) #1 acaramelado(s) a la factura (+$"+((getPrecioProducto(13))*cantidad)+")");
                            this.cantidadProducto[13] += cantidad;
                        } else {
                            respuestaCantidad("Combos# 1");
                            System.out.println("\tHas ingresado " + cantidad + " Combo(s) #1 a la factura (+$"+((getPrecioProducto(12))*cantidad)+")");
                            this.cantidadProducto[12] += cantidad;
                        }
                        salirOpcionCombo = true;
                        break;
                    case 2: //Combo 2
                        respuestaCantidad("Combos #2");
                        System.out.println("\tHas ingresado " + cantidad + " Combo(s) #2 a la factura (+$"+((getPrecioProducto(14))*cantidad)+")");
                        this.cantidadProducto[14] += cantidad;
                        salirOpcionCombo = true;
                        break;
                    case 3: //Combo 3
                        respuestaAcaramelado("Grande");
                        if (acaramelado) {
                            respuestaAumentarTamanoRefresco();
                            if (tamanoRefresco == 3) {
                                respuestaCantidad("Combos #3 acaramelados con Refresco Grande");
                                System.out.println("\tHas ingresado " + cantidad + " Combo(s) #3 acaramelado(s) con Refrescos Grandes a la factura (+$"+((getPrecioProducto(18))*cantidad)+")");
                                this.cantidadProducto[18] += cantidad;
                            } else if (tamanoRefresco == 2) {
                                respuestaCantidad("Combos #3 acaramelados");
                                System.out.println("\tHas ingresado " + cantidad + " Combo(s) #3 acaramelado(s) a la factura (+$"+((getPrecioProducto(16))*cantidad)+")");
                                this.cantidadProducto[16] += cantidad;
                            }
                        } else {
                            respuestaAumentarTamanoRefresco();
                            if (tamanoRefresco == 3) {
                                respuestaCantidad("Combos #3 con Refresco Grande");
                                System.out.println("\tHas ingresado " + cantidad + " Combo(s) #3 con Refrescos Grandes a la factura (+$"+((getPrecioProducto(17))*cantidad)+")");
                                this.cantidadProducto[17] += cantidad;
                            } else if (tamanoRefresco == 2) {
                                respuestaCantidad("Combos #3");
                                System.out.println("\tHas ingresado " + cantidad + " Combo(s) #3 a la factura (+$"+((getPrecioProducto(15))*cantidad)+")");
                                this.cantidadProducto[15] += cantidad;
                            }
                        }
                        salirOpcionCombo = true;
                        break;
                    case 4: //Cancelar Producto seleccionado y volver a Menu OpcionesFacturarPedido
                        System.out.println("\tCancelaste la opción de facturar un Combo");
                        salirOpcionCombo = true;
                        break;
                    default: //Opción ingresada invalida
                        System.out.println("\tHa introducido una opción incorrecta");
                        System.out.println("\tInténtelo nuevamente");
                }
            //Manejo de Excepciones en caso que usuario ingrese un dato no entero
            } catch (IOException e) {
                System.out.println("\tHa ocurrido un error de entrada/salida");
                System.out.println("\tInténtelo nuevamente");
            } catch (NumberFormatException e) {
                System.out.println("\tHa ingresado un valor invalido");
                System.out.println("\tInténtelo nuevamente");
            }
        } while(!salirOpcionCombo);
    }
}